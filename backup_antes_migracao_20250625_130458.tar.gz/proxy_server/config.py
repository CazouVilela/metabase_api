import os

PROXY_PORT = 3500
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR = os.path.join(BASE_DIR, '../componentes/dashboard_tabela')
