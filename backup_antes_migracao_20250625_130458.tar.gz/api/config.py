METABASE_BASE_URL = "http://localhost:3000"
METABASE_USERNAME = "cazouvilela@gmail.com"
METABASE_PASSWORD = "$Riprip001"
